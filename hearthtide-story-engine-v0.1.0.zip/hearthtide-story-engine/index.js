// Hearthtide Story Engine — companion module prototype
// Stores game state per chat, injects compact rules into the prompt, and renders choices only when the model marks a meaningful decision.
import { chat, chat_metadata, saveChatDebounced, setExtensionPrompt, extension_prompt_types, extension_prompt_roles } from '../../../../script.js';
import { eventSource, event_types } from '../../../../scripts/events.js';

const KEY = 'hearthtide_story_engine';
const PROMPT_KEY = 'hearthtide_story_engine_prompt';
const LS = 'hearthtide_story_engine_enabled';
const PRESETS = {
  modern: {
    label: 'Современность',
    modules: ['economy','career','social_reputation','relationships','education','housing','inventory','health','quests','memory'],
    currencies: 'местная валюта',
    rules: [
      'Деньги ограничены: покупка возможна только при достаточном балансе. Не разрешай тратить деньги дважды.',
      'Работа, доход, обязательные расходы, долги и имущество должны сохраняться между сценами.',
      'Социальная репутация зависит от того, кто знает о поступке; секреты не становятся общеизвестными без причины.',
      'Разделяй рабочую, личную, публичную и интернет-репутацию.',
      'События не должны происходить только ради активности: у них должны быть причины и последствия.'
    ]
  },
  fantasy: {
    label: 'Средневековье и фэнтези',
    modules: ['economy','career','titles','inheritance','estates','social_reputation','relationships','inventory','health','quests','memory','politics'],
    currencies: 'монеты мира',
    rules: [
      'Учитывай сословие, титул, владения, обязанности, наследование и доступные профессии.',
      'Покупки и услуги ограничены деньгами, доступностью товара, статусом и местными обычаями.',
      'Репутация дома и личная репутация связаны, но не тождественны.',
      'Не добавляй магию, если её нет в установленном сеттинге.',
      'События не должны происходить только ради активности: у них должны быть причины и последствия.'
    ]
  },
  historical: {
    label: 'Историческая эпоха',
    modules: ['economy','career','class','inheritance','property','social_reputation','relationships','inventory','health','quests','memory'],
    currencies: 'валюта эпохи',
    rules: [
      'Учитывай эпоху, регион, сословие, законы, доступные технологии и общественные нормы.',
      'Не переносить современные права, профессии, цены и обычаи в прошлое без основания.',
      'Имущество, приданое, долги и наследство должны иметь непротиворечивую историю.',
      'Репутация зависит от социального круга и того, что ему известно.'
    ]
  },
  scifi: {
    label: 'Научная фантастика и киберпанк',
    modules: ['economy','career','corporations','digital_reputation','social_reputation','relationships','inventory','cybernetics','health','quests','memory'],
    currencies: 'кредиты мира',
    rules: [
      'Учитывай стоимость технологий, доступ к оборудованию, лицензии, импланты и корпоративные ограничения.',
      'Цифровые следы и репутация меняются только при наличии правдоподобного источника информации.',
      'Не выдавай персонажу недоступное оборудование без оплаты, разрешения или сюжетного основания.'
    ]
  },
  mystery: {
    label: 'Детектив и триллер',
    modules: ['economy','career','social_reputation','relationships','evidence','suspects','secrets','quests','memory','health'],
    currencies: 'местная валюта',
    rules: [
      'Отличай факты, версии, ложные сведения и неизвестное.',
      'Не раскрывай тайну без улик или правдоподобного открытия.',
      'Учитывай, кто видел улику, кому её передали и кто знает о расследовании.',
      'Провал и задержка должны менять ситуацию, а не стирать уже известные факты.'
    ]
  },
  supernatural: {
    label: 'Ужасы и сверхъестественное',
    modules: ['economy','career','social_reputation','relationships','inventory','health','threats','secrets','quests','memory'],
    currencies: 'местная валюта',
    rules: [
      'Сохраняй установленные правила сверхъестественного и не меняй их ради удобства сцены.',
      'Ресурсы, травмы, угрозы и знания должны иметь последствия.',
      'Персонажи знают только то, что могли узнать.'
    ]
  },
  custom: {
    label: 'Свой сеттинг',
    modules: ['economy','career','social_reputation','relationships','inventory','health','quests','memory'],
    currencies: 'валюта мира',
    rules: ['Следуй описанию мира и пользовательским правилам; при противоречии не выдумывай факт молча.']
  }
};
const MODULES = {
  economy:'Экономика и торговля', career:'Работа и карьера', social_reputation:'Социальная репутация',
  digital_reputation:'Репутация в интернете', relationships:'Отношения и социальные связи',
  education:'Образование и навыки', housing:'Жильё и расходы', inventory:'Инвентарь и имущество',
  health:'Здоровье и потребности', quests:'Квесты и сюжетные события', memory:'Память и последствия',
  titles:'Титулы и сословия', inheritance:'Наследование', estates:'Земли и владения', politics:'Политика и интриги',
  class:'Сословия и нормы', property:'Собственность', corporations:'Корпорации', cybernetics:'Импланты и технологии',
  evidence:'Улики', suspects:'Подозреваемые', secrets:'Тайны', threats:'Угрозы'
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone = x => JSON.parse(JSON.stringify(x));
function freshState() {
  const p = PRESETS.custom;
  return {
    version: 1, preset: 'custom', settingName: '', turn: 0, lastChoiceTurn: -999, lastProcessedMessage: -1,
    modules: [...p.modules], rules: [...p.rules],
    economy: { currency: p.currencies, balance: null, income: null, expenses: null, debts: 0, ledger: [] },
    character: { name: '', occupation: '', employer: '', skills: [], possessions: [] },
    reputation: { work: 0, personal: 0, public: 0, online: 0, notes: [] },
    relationships: [], quests: [], facts: [], recentEvents: [], choices: [],
    config: { choiceCooldown: 5, showChoices: true, strictEconomy: true, maxChoices: 5 }
  };
}
function getState() {
  if (!chat_metadata[KEY] || chat_metadata[KEY].version !== 1) chat_metadata[KEY] = freshState();
  return chat_metadata[KEY];
}
function save() { saveChatDebounced(); }
function setPrompt() {
  const s = getState();
  if (!s || localStorage.getItem(LS) === 'false') {
    setExtensionPrompt(PROMPT_KEY, '', extension_prompt_types.IN_CHAT, 0, false, extension_prompt_roles.SYSTEM);
    return;
  }
  const modNames = s.modules.map(k => MODULES[k] || k).join(', ');
  const facts = (s.facts || []).slice(-18).map(x => `- ${x}`).join('\n') || '- Пока нет зафиксированных фактов.';
  const events = (s.recentEvents || []).slice(-10).map(x => `- ${x}`).join('\n') || '- Нет записанных недавних событий.';
  const rules = (s.rules || []).map(x => `- ${x}`).join('\n');
  const eco = s.economy || {};
  const balance = eco.balance == null ? 'не установлено' : `${eco.balance} ${eco.currency || ''}`;
  const rep = s.reputation || {};
  const stateBlock = `SETTING: ${s.settingName || PRESETS[s.preset]?.label || 'custom'}.
ACTIVE MODULES: ${modNames}.
CHARACTER STATE: name=${s.character?.name || 'unknown'}; occupation=${s.character?.occupation || 'not established'}; employer=${s.character?.employer || 'none established'}.
ECONOMY: balance=${balance}; income=${eco.income ?? 'unknown'}; recurring expenses=${eco.expenses ?? 'unknown'}; debts=${eco.debts ?? 0}. Currency: ${eco.currency || 'world currency'}.
REPUTATION (0 is neutral; -100..100): work=${rep.work ?? 0}; personal=${rep.personal ?? 0}; public=${rep.public ?? 0}; online=${rep.online ?? 0}.
CANON FACTS:
${facts}
RECENT EVENTS:
${events}
WORLD RULES:
${rules}`;
  const protocol = `
You are also operating a persistent, model-independent roleplay world state. Preserve established canon and do not silently overwrite it.
Only propose clickable choices at a genuine, consequential decision point. Do NOT show choices after every reply or during ordinary dialogue, action, description, or emotional beats. A choice point is appropriate when the protagonist must choose between materially different paths, offers, jobs, plans, risks, or responses, and the scene has reached a natural pause. Respect a cooldown of approximately ${s.config.choiceCooldown} assistant turns between choice cards unless a major decision cannot reasonably wait.
Never decide the user's character's thoughts, feelings, dialogue, or actions for them.
Economy is a hard constraint when known: never narrate a completed purchase if balance is insufficient. Offer cheaper alternatives, saving, bargaining, credit/loan only if plausible, or refusal. Do not invent income, wealth, possessions, jobs, promotions, or debt repayment. If a value is unknown, keep it unknown rather than assuming abundance.
A character's profession/employer changes only after a plausible hiring, resignation, firing, transfer, or other explicit event. Track commitments, deadlines, possessions, relationships, reputation, injuries, and consequences. Secrets are not public knowledge unless someone plausibly reveals them. Do not repeat a completed or rejected event without a reason.
Keep the prose natural and immersive; state tracking must never turn the roleplay into a dry game log.
At the END of a response, emit compact machine-readable metadata ONLY when something materially changed or a genuine choice is available. Use HTML comments so it is not visible in the rendered story:
<!--HT-SE-UPDATE: {"facts_add":["..."],"events_add":["..."],"character":{"occupation":"...","employer":"..."},"economy":{"balance":123},"reputation":{"work":5},"quests_add":["..."],"relationships_add":[{"name":"...","status":"..."}]}-->
<!--HT-SE-CHOICES: [{"id":"stable-id","title":"Short action","detail":"Brief consequence or trade-off"}]-->
Omit either comment entirely if it is not needed. JSON must be valid. Only include fields that truly changed. For choices, provide 2-${s.config.maxChoices} materially different, contextually possible actions. Do not create a choice card just to fill space. Never set an economy balance based on an attempted transaction that failed.`;
  setExtensionPrompt(PROMPT_KEY, `${protocol}\n\n${stateBlock}`, extension_prompt_types.IN_CHAT, 1, false, extension_prompt_roles.SYSTEM);
}
function parseComment(text, kind) {
  const re = new RegExp(`<!--\\s*HT-SE-${kind}:\\s*([\\s\\S]*?)\\s*-->`, 'i');
  const m = text.match(re);
  if (!m) return { value: null, clean: text };
  try { return { value: JSON.parse(m[1]), clean: text.replace(m[0], '').trim() }; }
  catch { return { value: null, clean: text.replace(m[0], '').trim() }; }
}
function clamp(n, min=-100, max=100) { n = Number(n); return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : null; }
function applyUpdate(u, turn) {
  if (!u || typeof u !== 'object') return;
  const s = getState();
  const addUnique = (arr, items, cap=60) => {
    for (const item of Array.isArray(items) ? items : []) {
      const v = String(item ?? '').trim();
      if (v && !arr.includes(v)) arr.push(v);
    }
    while (arr.length > cap) arr.shift();
  };
  addUnique(s.facts, u.facts_add, 100);
  addUnique(s.recentEvents, u.events_add, 30);
  addUnique(s.quests, u.quests_add, 50);
  if (u.character && typeof u.character === 'object') {
    for (const k of ['name','occupation','employer']) if (typeof u.character[k] === 'string') s.character[k] = u.character[k].slice(0,160);
    if (Array.isArray(u.character.skills)) s.character.skills = [...new Set(u.character.skills.map(String))].slice(0,30);
    if (Array.isArray(u.character.possessions)) s.character.possessions = [...new Set(u.character.possessions.map(String))].slice(0,80);
  }
  if (u.economy && typeof u.economy === 'object') {
    const e = s.economy;
    if (typeof u.economy.currency === 'string') e.currency = u.economy.currency.slice(0,60);
    // Strict economy: the model cannot directly set balance upward. It must describe a ledger transaction.
    // User can manually correct the balance in settings. Income/spending is accepted only as a validated transaction.
    if (typeof u.economy.balance === 'number' && Number.isFinite(u.economy.balance)) {
      const next = Math.max(0, Math.round(u.economy.balance * 100) / 100);
      const old = typeof e.balance === 'number' ? e.balance : null;
      const reason = String(u.economy.reason || '').slice(0,180);
      const kind = u.economy.kind;
      if (old === null) {
        // Initial balance may be established once from explicit story evidence.
        if (u.economy.initial === true) e.balance = next;
      } else if (kind === 'income' && next >= old && reason) {
        e.balance = next; e.ledger.push({ turn, kind, amount: +(next-old).toFixed(2), reason });
      } else if (kind === 'expense' && next <= old && reason) {
        e.balance = next; e.ledger.push({ turn, kind, amount: +(old-next).toFixed(2), reason });
      } else if (kind === 'correction' && u.economy.user_confirmed === true) {
        e.balance = next; e.ledger.push({ turn, kind, amount: +(next-(old||0)).toFixed(2), reason: reason || 'manual correction' });
      }
      e.ledger = e.ledger.slice(-80);
    }
    for (const k of ['income','expenses','debts']) if (typeof u.economy[k] === 'number' && Number.isFinite(u.economy[k])) e[k] = Math.max(0, Math.round(u.economy[k]*100)/100);
  }
  if (u.reputation && typeof u.reputation === 'object') {
    for (const k of ['work','personal','public','online']) {
      const n = clamp(u.reputation[k]);
      if (n !== null) s.reputation[k] = n;
    }
    if (Array.isArray(u.reputation.notes)) addUnique(s.reputation.notes, u.reputation.notes, 50);
  }
  if (Array.isArray(u.relationships_add)) {
    for (const r of u.relationships_add.slice(0,8)) if (r && typeof r.name === 'string') {
      const old = s.relationships.find(x => x.name.toLowerCase() === r.name.toLowerCase());
      if (old) Object.assign(old, {status: String(r.status || old.status || '').slice(0,180)});
      else s.relationships.push({name:r.name.slice(0,100),status:String(r.status||'').slice(0,180)});
    }
    s.relationships = s.relationships.slice(-80);
  }
  s.turn = Math.max(s.turn || 0, turn);
  save(); setPrompt(); renderPanel(); renderChoices();
}
function latestBot() {
  for (let i=chat.length-1;i>=0;i--) if (chat[i] && !chat[i].is_user && !chat[i].is_system) return {m:chat[i],i};
  return null;
}
function processLatest() {
  const x = latestBot(); if (!x) return;
  let raw = x.m.mes || '';
  const up = parseComment(raw,'UPDATE');
  const ch = parseComment(up.clean,'CHOICES');
  const s=getState();
  const isNewMessage = x.i !== s.lastProcessedMessage;
  if (isNewMessage && !ch.value) s.choices = [];
  if (up.value) applyUpdate(up.value,x.i);
  if (up.value || ch.value) {
    x.m.mes = ch.clean;
    saveChatDebounced();
    if (ch.value && Array.isArray(ch.value)) {
      if (s.config.showChoices && x.i - (s.lastChoiceTurn ?? -999) >= Number(s.config.choiceCooldown || 5)) {
        s.choices = ch.value.slice(0, Number(s.config.maxChoices)||5).filter(c=>c && typeof c.title==='string').map((c,j)=>({id:String(c.id||`${x.i}-${j}`).slice(0,100),title:c.title.slice(0,100),detail:String(c.detail||'').slice(0,220)}));
        if (s.choices.length) s.lastChoiceTurn=x.i;
      }
    }
  }
  s.lastProcessedMessage=x.i;
  save(); renderChoices();
}
function sendChoice(choice) {
  const text = `I choose: ${choice.title}${choice.detail ? ` (${choice.detail})` : ''}. Continue the roleplay from this choice, preserving established facts and consequences.`;
  const area = document.querySelector('#send_textarea');
  const btn = document.querySelector('#send_but');
  if (!area || !btn) { window.toastr?.warning?.('Не удалось найти поле ввода SillyTavern. Скопируй вариант вручную.','Story Engine'); return; }
  area.value = text;
  area.dispatchEvent(new Event('input',{bubbles:true}));
  btn.click();
}
function renderChoices() {
  const x=latestBot(); if(!x) return;
  const el=document.querySelector(`#chat .mes[mesid="${x.i}"]`);
  if(!el) return;
  let host=el.querySelector('.htse-choices');
  const s=getState();
  if(!s.config.showChoices || !s.choices?.length) { host?.remove(); return; }
  if(host) host.remove();
  host=document.createElement('div'); host.className='htse-choices';
  const title=document.createElement('div'); title.className='htse-choice-heading'; title.textContent='Возможные действия'; host.append(title);
  for(const c of s.choices) {
    const b=document.createElement('button'); b.className='htse-choice';
    const strong=document.createElement('strong'); strong.textContent=c.title; b.append(strong);
    if(c.detail) { const d=document.createElement('span'); d.textContent=c.detail; b.append(d); }
    b.addEventListener('click',()=>sendChoice(c));
    host.append(b);
  }
  el.append(host);
}
function ensurePanel() {
  if(document.getElementById('htse-panel')) return;
  const root=document.querySelector('#extensions_settings2') || document.querySelector('#extensions_settings');
  if(!root) return;
  const wrap=document.createElement('div'); wrap.id='htse-panel'; wrap.className='extension_container';
  wrap.innerHTML=`<div class="inline-drawer">
    <div class="inline-drawer-toggle inline-drawer-header"><b>Hearthtide Story Engine</b><div class="inline-drawer-icon fa-solid fa-circle-chevron-down"></div></div>
    <div class="inline-drawer-content">
      <div class="htse-row"><label for="htse-enabled">Включить движок</label><input id="htse-enabled" type="checkbox" checked></div>
      <div class="htse-row"><label for="htse-preset">Набор сеттинга</label><select id="htse-preset">${Object.entries(PRESETS).map(([k,v])=>`<option value="${k}">${esc(v.label)}</option>`).join('')}</select></div>
      <div class="htse-row"><label for="htse-name">Название сеттинга / мира</label><input id="htse-name" type="text" placeholder="Например, современный Бишкек или Вестерос"></div>
      <div class="htse-row"><label for="htse-balance">Баланс персонажа (пусто = неизвестен)</label><input id="htse-balance" type="number" step="0.01" min="0" placeholder="Не установлено"></div>
      <div class="htse-row"><label for="htse-currency">Валюта</label><input id="htse-currency" type="text" placeholder="Монеты, сомы, кредиты..."></div>
      <div class="htse-row"><label for="htse-occupation">Профессия</label><input id="htse-occupation" type="text" placeholder="Пока не установлена"></div>
      <div class="htse-row"><label for="htse-employer">Работодатель / организация</label><input id="htse-employer" type="text" placeholder="Нет / неизвестно"></div>
      <div class="htse-row"><label for="htse-cooldown">Минимум ходов между выборами</label><input id="htse-cooldown" type="number" min="1" max="30" value="5"></div>
      <div class="htse-row"><label for="htse-modules">Активные модули</label><div id="htse-modules" class="htse-modules"></div></div>
      <div class="htse-row"><label for="htse-rules">Дополнительные правила (по одному на строку)</label><textarea id="htse-rules" rows="5"></textarea></div>
      <div class="htse-buttons"><button id="htse-apply" class="menu_button">Сохранить настройки</button><button id="htse-export" class="menu_button">Экспорт состояния</button><button id="htse-import" class="menu_button">Импорт состояния</button><button id="htse-reset" class="menu_button">Сбросить состояние этого чата</button></div>
      <div id="htse-status" class="htse-status"></div>
      <div class="htse-small">Прототип: состояние хранится в метаданных текущего чата. Кнопки появляются только при явной сюжетной развилке, если модель корректно выдаёт служебный маркер.</div>
    </div></div>`;
  root.append(wrap);
  wrap.querySelector('.inline-drawer-toggle').addEventListener('click',()=>wrap.querySelector('.inline-drawer').classList.toggle('open'));
  wrap.querySelector('#htse-enabled').checked=localStorage.getItem(LS)!=='false';
  wrap.querySelector('#htse-preset').addEventListener('change',e=>{
    const s=getState(), p=PRESETS[e.target.value]; if(!p)return;
    s.preset=e.target.value; s.modules=[...p.modules]; s.rules=[...p.rules]; s.economy.currency=p.currencies;
    save(); fillPanel(); setPrompt();
  });
  wrap.querySelector('#htse-enabled').addEventListener('change',e=>{localStorage.setItem(LS,e.target.checked?'true':'false');setPrompt();});
  wrap.querySelector('#htse-apply').addEventListener('click',()=>{
    const s=getState();
    s.settingName=wrap.querySelector('#htse-name').value.trim();
    const bal=wrap.querySelector('#htse-balance').value;
    s.economy.balance=bal===''?null:Math.max(0,Number(bal)||0);
    s.economy.currency=wrap.querySelector('#htse-currency').value.trim()||s.economy.currency;
    s.character.occupation=wrap.querySelector('#htse-occupation').value.trim();
    s.character.employer=wrap.querySelector('#htse-employer').value.trim();
    s.config.choiceCooldown=Math.max(1,Math.min(30,Number(wrap.querySelector('#htse-cooldown').value)||5));
    s.modules=[...wrap.querySelectorAll('[data-module]:checked')].map(e=>e.dataset.module);
    s.rules=wrap.querySelector('#htse-rules').value.split('\n').map(x=>x.trim()).filter(Boolean);
    save();setPrompt();renderPanel(); status('Настройки сохранены для этого чата.');
  });
  wrap.querySelector('#htse-export').addEventListener('click',()=>{
    const blob=new Blob([JSON.stringify(getState(),null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='hearthtide-story-state.json';a.click();URL.revokeObjectURL(a.href);
  });
  wrap.querySelector('#htse-import').addEventListener('click',()=>{
    const input=document.createElement('input');input.type='file';input.accept='.json,application/json';
    input.onchange=async()=>{const f=input.files?.[0];if(!f)return;try{const obj=JSON.parse(await f.text());if(!obj||obj.version!==1||!Array.isArray(obj.modules)||!obj.economy)throw Error('Файл не похож на экспорт Story Engine');chat_metadata[KEY]=obj;save();fillPanel();setPrompt();renderPanel();status('Состояние импортировано.');}catch(e){status(`Ошибка импорта: ${e.message}`);}};input.click();
  });
  wrap.querySelector('#htse-reset').addEventListener('click',()=>{
    if(!confirm('Сбросить состояние Story Engine только в этом чате?'))return;
    chat_metadata[KEY]=freshState();save();fillPanel();setPrompt();renderPanel();status('Состояние этого чата сброшено.');
  });
  fillPanel();
}
function status(t){const el=document.querySelector('#htse-status');if(el)el.textContent=t;}
function fillPanel() {
  const root=document.getElementById('htse-panel');if(!root)return;
  const s=getState();
  root.querySelector('#htse-preset').value=s.preset||'custom';
  root.querySelector('#htse-name').value=s.settingName||'';
  root.querySelector('#htse-balance').value=s.economy.balance??'';
  root.querySelector('#htse-currency').value=s.economy.currency||'';
  root.querySelector('#htse-occupation').value=s.character.occupation||'';
  root.querySelector('#htse-employer').value=s.character.employer||'';
  root.querySelector('#htse-cooldown').value=s.config.choiceCooldown||5;
  root.querySelector('#htse-rules').value=(s.rules||[]).join('\n');
  const mods=root.querySelector('#htse-modules');
  mods.innerHTML=Object.entries(MODULES).map(([k,v])=>`<label class="htse-module"><input type="checkbox" data-module="${k}" ${s.modules.includes(k)?'checked':''}><span>${esc(v)}</span></label>`).join('');
}
function renderPanel() {
  const root=document.getElementById('htse-panel');if(!root)return;
  const s=getState();
  const old=root.querySelector('.htse-state-summary');old?.remove();
  const summary=document.createElement('div');summary.className='htse-state-summary';
  const rep=s.reputation||{};
  summary.innerHTML=`<b>Текущее состояние</b><div>Фактов: ${(s.facts||[]).length} · Событий: ${(s.recentEvents||[]).length} · Квестов: ${(s.quests||[]).length}</div><div>Репутация: работа ${rep.work??0}, личная ${rep.personal??0}, публичная ${rep.public??0}, онлайн ${rep.online??0}</div><div>Записей экономики: ${(s.economy?.ledger||[]).length}</div>`;
  root.querySelector('.inline-drawer-content')?.append(summary);
}
function onMessageReceived() {
  setTimeout(()=>{processLatest();renderPanel();renderChoices();},250);
}
function onChatChanged() {
  setTimeout(()=>{ensurePanel();fillPanel();setPrompt();renderPanel();renderChoices();},300);
}
function init() {
  ensurePanel(); fillPanel(); setPrompt(); renderPanel();
  if(event_types.MESSAGE_RECEIVED)eventSource.on(event_types.MESSAGE_RECEIVED,onMessageReceived);
  if(event_types.GENERATION_ENDED)eventSource.on(event_types.GENERATION_ENDED,()=>{setTimeout(renderChoices,200);});
  if(event_types.CHAT_CHANGED)eventSource.on(event_types.CHAT_CHANGED,onChatChanged);
  if(event_types.MESSAGE_DELETED)eventSource.on(event_types.MESSAGE_DELETED,()=>{setTimeout(()=>{processLatest();renderChoices();},200);});
  // Settings DOM can be mounted after extension init in some builds.
  setTimeout(ensurePanel,800);
}
jQuery(()=>init());
